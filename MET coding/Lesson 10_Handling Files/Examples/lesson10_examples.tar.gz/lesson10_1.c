
#include<stdio.h>

int main()
   {
     FILE *fp;
     char hold[45];
     int  i;

      fp = fopen("test.txt", "w");   /* open for writing */
      strcpy(hold, "HELLO WORLD, AGAIN.");
      for(i = 1 ; i < 20 ; i++)
	   fprintf(fp, "%s  Line number %d\n", hold, i);
       fclose(fp);    
       return(0); 
    }

