  #include<stdio.h>   
  int main()
      {
        FILE *fp;
	char hold[45];
	int  i;

	fp = fopen("test2.txt", "w");   /* open for writing */
	strcpy(hold, "HELLO WORLD, AGAIN AND AGAIN");
	     
        for(i = 0; i < 28; i++)
	   putc(hold[i],fp);
        fclose(fp);    
        return(0); 
       }

