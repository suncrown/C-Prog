#include<stdio.h>
#include<stdlib.h>
int main()
       {
	FILE *fptr;
	int k;
        fptr = fopen("test.txt", "r");
	if(fptr == NULL) 
	   {
	   printf("File NOT Found\n");
	   exit(1);
	   } 
	 else 
	   {
	      do 
      	       {
                k = getc(fptr);    
	         putchar(k);        
	       } while (k != EOF);    
           }
                 fclose(fptr);
	} 





