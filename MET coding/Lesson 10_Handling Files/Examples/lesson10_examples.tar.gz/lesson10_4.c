#include<stdio.h>
int main()
  {
   FILE *fptr;
   char buffer[400];
   int k;
   fptr = fopen("test.txt", "r");
   do 
     {
       k = fscanf(fptr, "%s", buffer); 
       /*if(k != EOF)*/
         printf("%s\n", buffer);     
     } while (k != EOF);                
    fclose(fptr);
    return(0);
   }

