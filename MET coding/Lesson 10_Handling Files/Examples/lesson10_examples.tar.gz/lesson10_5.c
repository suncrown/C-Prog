#include<stdio.h>
int main()
  {
   FILE *fptr;
   char buffer[400];
   char *k;
   fptr = fopen("test.txt", "r");
   do 
     {
       k = fgets(buffer, 300, fptr); 
       /*if(k != EOF)*/
         printf("%s\n", buffer);     
     } while (k != NULL);                
    fclose(fptr);
    return(0);
   }

