#include<stdio.h>
#include<stdlib.h>

int main()
   {
   FILE *fptr;
   char buffer[80], file[20];
   char *k;
   printf("Enter filename -> ");
   scanf("%s", file);
   fptr = fopen(file, "r");
   if(fptr == NULL)
     {
     printf("File NOT found \n");
     exit(1);
     }
   do
     {
     k = fgets(buffer, 80, fptr);
     if(k != NULL)
       printf("%s", buffer);
     }while (k != NULL);
   fclose(fptr);
   return(0);
   }

