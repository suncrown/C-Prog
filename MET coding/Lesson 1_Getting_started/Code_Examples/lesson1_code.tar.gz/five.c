/* The very useful printf  */ 
#include <stdio.h>
int main()
{
 char ICode = 'T';
 int PartNo = 15;
 float cost = 17.5;
 printf("%c       %d %f", ICode, PartNo, cost);
 return(0);
}
