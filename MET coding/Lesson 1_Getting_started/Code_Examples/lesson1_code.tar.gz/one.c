/*The sample code will display the message "This is C programming."*/
#include <stdio.h>
int main()
{
printf("This is C programming.");
return(0);
}
