/* increment decrement  operator ++ , -- */
#include <stdio.h>
int main()
{
 int k = 1;
 printf("%d\n", k);
 printf("%d\n", ++k);
 printf("%d\n", k);
 printf("%d\n", k++);
 printf("%d\n", k);

 k = 1 ; 
 
 printf("%d\n", k);
 printf("%d\n", --k); 
 printf("%d\n",k);
 printf("%d\n",k--);
 printf("%d\n",k);

 return(0);
}
