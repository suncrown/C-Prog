/* using getc with stdin instead of getchar */ 
#include <stdio.h>
int main()
{
char choice;
choice = getc(stdin);
putchar(choice);
return(0);
}
