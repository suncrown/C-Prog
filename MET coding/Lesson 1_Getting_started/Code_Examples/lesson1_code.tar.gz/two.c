
/* getchar and putchar */ 
#include <stdio.h>
int main()
{
char answer;
answer = getchar();
putchar(answer);
return(0);
}
