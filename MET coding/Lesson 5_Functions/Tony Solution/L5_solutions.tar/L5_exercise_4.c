#include<stdio.h>

void hist(int); /* prototype */

 int main(void)
 {
  int st1,st2,st3,st4,st5,st6;
  printf("\nPlease enter the six exam score \n");
  scanf("%d,%d,%d,%d,%d,%d",&st1,&st2,&st3,&st4,&st5,&st6);
  hist(st1);
  hist(st2);
  hist(st3);
  hist(st4);
  hist(st5);
  hist(st6);
  printf("\n");
 }
  
 void hist(int h)
 {
  int i;
  printf("\n");
  for(i=0;i<h;i++)
  printf("#" );
  
 }
