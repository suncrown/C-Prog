#include<stdio.h>

int main(void)
 {
 char name[20];
 printf("Please enter your name: ");
 scanf("%s",name);
 printf("Greetings,%s.",name);
 return(0);
 } 
