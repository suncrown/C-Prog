#include<stdio.h>
#include<string.h> 

void main(void)
 {
  char name[20];
  char greet[] = "Hello : ";
  puts("INPUT YOUR NAME (19 characters)");
  scanf("%s",&name);
  puts("Hello");
  puts(name);
  puts(strcat(greet,name));
 }
