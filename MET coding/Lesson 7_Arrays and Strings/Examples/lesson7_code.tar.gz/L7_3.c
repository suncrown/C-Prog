#include<string.h>
#include<stdio.h>
 
int main(void)
 {
  char name[20];
  char mess[]= "Hi there, ";
  int len;
  puts("INPUT YOUR NAME (19 characters)");
  fgets(name,sizeof(name),stdin);
  puts("Hello");
  puts(name);
  strcat(mess,name);
  puts(mess);
  len = strlen(mess);
  printf("The length of the message is %d\n",len);
  return(0);
 }
