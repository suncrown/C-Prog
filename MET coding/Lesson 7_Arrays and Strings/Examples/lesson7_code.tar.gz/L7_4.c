#include<stdio.h>
#include<math.h>

void main(void)
 {
 int graph[6][2];
 int row,col;
 for(row=0;row<=5;row++)
 for(col=0;col<=1;col++)
  graph[row][col]= pow(row,2);
 
 for(row=0;row<=5;row++)
 for(col=0;col<=1;col++)
 printf("x[%d]=%d \n",row,graph[row][col]); 
 } 
