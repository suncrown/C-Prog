
 #include<stdio.h> 
 void fill_array(int[],int); /*function prototype*/
 
 void main(void)
 {
 int j;
 int list[5];
 fill_array(list,5); /* function call */
 for(j=0;j<5;j++)
 printf("list[%d]=%d \n",j, list[j]);
 }
 
 void fill_array(int hold[],int n) /*function defination*/ 
 {
 int i;
 for(i=0;i<n;i++) 
 { 
 printf(" Enter interger number \n");
 scanf("%d",&hold[i]);
 }
 }
