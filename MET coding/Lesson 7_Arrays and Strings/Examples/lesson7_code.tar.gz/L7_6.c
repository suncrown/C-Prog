#define num 4
#define size 20
#include<stdio.h>
#include<string.h>
   
int main(void)
     {
      int i,check=0;        
      char name[size];
      static char list[num][size] = { "John",
                                 "Pat",                                 
                                 "June",                                                                         "Kate" };       
      puts(" ENTER YOUR NAME");        
      scanf("%s",&name);       
      for(i=0;i<=3;i++)
         if(strcmp(&list[i][0],name)==0) check=1;
           
      if(check)
         printf("YOU MAY ENTER");           
      else
         printf("SORRY ,NO ENTRY");
      return(0);
      }   

