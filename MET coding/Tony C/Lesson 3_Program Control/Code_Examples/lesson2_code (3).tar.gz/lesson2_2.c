
#include<stdio.h>
void main(void)
        {
         float years, days;
         printf("Type in your age in years: ");                
         scanf("%f",&years);             
         days = years * 365;
         printf(" you are %.1f days old\n",days);            
        } 
