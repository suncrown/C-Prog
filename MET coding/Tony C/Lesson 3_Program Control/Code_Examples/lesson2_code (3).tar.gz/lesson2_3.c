#include<stdio.h>
void main(void)          
     {        
      int money;              
      money = 23;
      printf("Is the amount of cash less than 21 ? %d \n",money < 24 );               money = 56;
      printf("Is the amount of cash less than 21 ? %d \n",money < 24 );        
     } 
