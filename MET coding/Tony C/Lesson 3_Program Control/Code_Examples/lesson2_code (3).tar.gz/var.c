#include<stdio.h>  

void main(void)       
{        
  int event;        
  char heat;        
   float time;        
   event =5;        
   heat ='C';        
   time = 27.25;
    printf(" The winning time in heat %c",heat);        
    printf(" of event %d was %f\n",event, time);
  }  
