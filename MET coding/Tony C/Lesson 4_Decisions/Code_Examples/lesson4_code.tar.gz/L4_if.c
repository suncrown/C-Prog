
#include<stdio.h>

void main(void)
 {
 char ch;
 scanf("%c",&ch);
 if( ch=='z')
  printf("\n YOU HAVE INPUT A z\n");
 } 
