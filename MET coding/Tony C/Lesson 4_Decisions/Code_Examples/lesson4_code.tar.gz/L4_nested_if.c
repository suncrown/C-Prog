#include<stdio.h>

int main(void)
 {
 char ch1,ch2,ch3;
 scanf("%c%c%c",&ch1,&ch2,&ch3);
 if( ch1=='D')
 if(ch2=='A')
 if(ch3=='N')
 printf("\n YOU HAVE INPUT - DAN\n");
 return(0);
 }

