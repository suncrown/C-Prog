#include<stdio.h>

int main(void)
 {
  int money;
  printf("HOW MUCH DO YOU EARN A WEEK(€0-500):\n");
  scanf("%d",&money);
  if( money < 350 )
   if( money > 250)
   printf("\nYour earnings are close to the average weekly wage\n");
   else
   printf("\nYour earnings are different to the average weekly wage\n");
   return(0);
 } 



