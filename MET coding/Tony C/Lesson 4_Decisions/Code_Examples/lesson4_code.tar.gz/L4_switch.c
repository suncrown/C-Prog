#include <stdio.h>

int main()
 {
  int i;
  for(i=0;i<=3;i++) 
    {
     switch(i) 
       {
        case 0: printf("i=zero\n");
        break;
        case 1: printf("i=one\n");
        break;
        case 2: printf("i=two\n");
        break; 
        default:printf(" i is not 0,1,2 \n");
        break;
        } 
     } 
  return 0;
  }
