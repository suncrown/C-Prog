#include<stdio.h>

void drawbox(void); /* prototype */

 int main(void)
 {
  drawbox();
  printf(" Welcome to C ");
  drawbox();
 }
  
 void drawbox(void) /* declaration */
  {
   int k;
   printf("\n##################");
   for(k=1;k<=5;k++)
   printf("\n#\t\t #");
   printf("\n##################\n");
  }
