 #include<stdio.h> 
 void draw_rect(int,int);
 
 void main(void)
 {
 printf("\nSITTINGROOM\n");
 draw_rect(22,14);
 printf("\nBATHROOM\n");
 draw_rect(6,6);
 printf("\nBEDROOM \n");
 draw_rect(10,8);
 }
 
 
 void draw_rect(int x,int y)
 {
 int i,j;
 x/=2;y/=2; /*scaling factor*/
 for(i=1;i<=x;i++)
 {
 printf("\t\t");
 for(j=1;j<=y;j++)
 printf("\|");
 printf("\n");
 } 
 }
