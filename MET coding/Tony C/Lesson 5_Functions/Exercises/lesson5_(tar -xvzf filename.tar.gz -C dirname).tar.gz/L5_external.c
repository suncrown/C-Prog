 #include<stdio.h> 
 int radius; /*external or global variable*/
 
 float circle();
 float sphere();
 
 int main(void)
 {
 puts("ENTER THE RADIUS YOU WISH TO USE");
 scanf("%d",&radius);
 printf("\n THE CIRCLE OF RADIUS %d HAS AREA %f\n",radius,circle());
 printf("\n THE SPHERE OF RADIUS %d HAS VOL %f\n",radius,sphere());
 return(0);
 }
 
 float circle(void)
 {
 return(3.14*radius*radius);
 }
 
 float sphere(void)
 {
 return( (4.0/3.0)*(3.14)*(radius*radius*radius));
 }
