 #include<stdio.h>
 #include<math.h>
 double square_root(void); /* prototype */
 
 int main()
 { 
  printf("square root of 10 = %e \n",square_root());
  return(0);
 }
 
 double square_root(void)
  {
  double num=10.0;
  return(pow(num,0.5));
  }
