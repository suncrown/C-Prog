 #include<stdio.h>
 #include<math.h>
 
 double square_root(float);
 
int main()
 { 
  float num;
  printf("Enter he number you wish to find the square root of:  ");
  scanf("%f",&num);
  printf("square root of %f = %e \n",num,square_root(num));
  return(0);
 }
 
double square_root(float hold)
  {
  return(pow(hold,0.5));
  }

