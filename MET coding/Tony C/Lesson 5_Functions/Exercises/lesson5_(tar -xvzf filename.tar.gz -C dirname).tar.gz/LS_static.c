#include<stdio.h>

void callme();

int main(void)
{
callme();
callme();
callme();
callme();
}


void callme() /* comment/uncomment on line below*/
{
/*static int num=0;*/
int num=0;
num++;
printf("The function was called  %d times\n",num);
}





