 #define PI 3.14159
 #include<stdio.h>
 
 int main(void)
  {
  float radius;
  printf(" type in the radius\n");
  scanf("%f",&radius);
  printf("area = %f \n",PI*radius*radius);
  return(0);
  }



