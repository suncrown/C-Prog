#include<stdio.h>

int binarysearch(int [],int, int)


int main()
{

}

int binarysearch(int holdnum[],int x,int size)
{
 int start, end, middle; 
 end = size - 1 ;
 while(start <= end)
     { 
      middle = (start+end)/2;
      if(x < holdnum[middle]) end = middle - 1; 
      else 
      if(x < hold   )  
     } 




}


