#include<stdio.h>

/* This program demonstrates the passing and returning  of a structure to a function */ 

struct point{
            int x;
            int y; 
            };


struct point definepoint(int, int);
void   print_struct(struct point);



int main()
{
struct point PT1;
int x,y;
x = 5; y=9;
PT1 = definepoint(x,y);   /* empty structure is passed to a function and assigned  values */
print_struct(PT1);
return(0);
}


struct point definepoint(int x1, int y1)
{
struct point M; 
M.x = x1;
M.y = y1;
return(M);
}

void print_struct(struct point N)
{
puts("STRUCTURE POINT ");
printf("x=%d : y=%d ", N.x, N.y); 
} 

