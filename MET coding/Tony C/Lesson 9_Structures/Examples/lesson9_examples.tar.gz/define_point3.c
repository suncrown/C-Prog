#include<stdio.h>
#include<stdlib.h>

/* This program demonstrates the passing and returning of a pointertoa structure to/from a function */ 

struct point{
            int x;
            int y; 
            };


struct point *definepoint(int, int);
void   print_struct(struct point *);


int main()
{
 struct point *PT1;
 int x,y;
 x = 5; y=9;
 PT1 = definepoint(x,y);   /* integer values passed to a function for assignment */
 print_struct(PT1);        /* print out the contents of the point */
 return(0);
}


struct point *definepoint(int x1, int y1)
{
 struct point *M;
 M = malloc(sizeof(struct point)); /* sets aside space in memory to store a structure */
 
 M->x =  x1;        /* point assignment to structure*/
 
 (*M).y =  y1;      /* alternative notation(less common) */

 return(M);
}

void print_struct(struct point *N)
{
 puts("STRUCTURE POINT ");
 printf("x=%d : y=%d ", N->x, N->y); 
} 

