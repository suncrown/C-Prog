#include<stdio.h>
#include<string.h>

/* Note that the struct is defined outside of main 
 * 4 variables of type data are declared ....at different places, 
 * with different scope and initialised differently
 * */

struct data
{
 char name[50];
 int  salary;
} employee1,employee2;  

struct data employee3 = {"Mary J Fox", 5678};

int main()
{
 struct data employee4 = {"Chris Penn", 9999}; 
 
 strcpy(employee1.name, "Robert Lee Clark");
 strcpy(employee2.name, "Debbie Harry");
 
 employee1.salary = 3455;
 employee2.salary = 2376; 
 
 
 printf("\n Employee 1:name: %s  salary:%d  ",employee1.name,employee1.salary); 
 printf("\n Employee 2:name: %s  salary:%d  ",employee2.name,employee2.salary); 
 printf("\n Employee 3:name: %s  salary:%d  ",employee3.name,employee3.salary);
 printf("\n Employee 4:name: %s  salary:%d  ",employee4.name,employee4.salary);
 return(0);
}

