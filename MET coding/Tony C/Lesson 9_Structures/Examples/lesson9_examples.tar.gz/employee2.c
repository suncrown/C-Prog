#include<stdio.h>

struct data
{
 char name[20];
 int  salary;
} employee1,employee2;  

/* A structure called data is defined - note its visibility or scope
 * Notice the scanf below and the format specifiers that are used to 
 * take in strings with white space etc.   
 *
 * */


int main()
{
 printf("Employee1: Please Enter Name:");
 scanf("%[^\n]s",&employee1.name); 
 printf("Employee1: Please Enter Salary(integer val):" );
 scanf("%d",&employee1.salary); 

 printf("Employee2: Please Enter Name:");
 scanf("%*c%[^\n]s",&employee2.name);
 printf("Employee2: Please Enter SalaryIinteger val):");
 scanf("%d",&employee2.salary);

 printf("\n Employee 1:name: %s  salary:%d  ",employee1.name,employee1.salary); 
 printf("\n Employee 2:name: %s  salary:%d  ",employee2.name,employee2.salary); 

 return(0);
}

