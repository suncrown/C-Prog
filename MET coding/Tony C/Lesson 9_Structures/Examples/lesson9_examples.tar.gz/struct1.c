#include<stdio.h>

struct child
{
 char initial;
 int  age;
 int  grade;
} children[12], *point, extra;  

/* a structure called child is defined and 3 variables of this type
 * are declared – an array of size 12 called children, a variable called 
 * extra and a pointer variable called point. All have global scope  
 *       
*/


int main()
{
 int index;
 for(index = 0 ; index < 12 ; index++)
    {
     point = children + index;
     point->initial = 'A' + index;
     point->age = 16;
     point->grade = 84;
    }

  children[3].age = children[5].age = 19;
  children[2].grade = children[6].grade = 90;
  children[4].grade = 67;

  for(index = 0 ; index < 12 ; index++) 
    {
     point = children + index;
     printf("%c is %d years old and got a grade of  %d\n",(*point).initial,children[index].age,point->grade);
    }
  extra = children[2];               /* Structure assignment */
  extra = *point;                    /* Structure assignment */
  printf("\n Extra Initial:%c  Age:%d  Grade%d",extra.initial,extra.age,extra.grade); 
  return(0);
}

