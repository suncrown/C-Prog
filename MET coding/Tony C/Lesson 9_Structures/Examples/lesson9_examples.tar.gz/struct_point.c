#include<stdio.h>

/* With help of the random rand() function  
 * random point are constructed 
 *
*/ 

struct Point
{
   int x, y;
};
 
int main()
{
 int i;
 struct Point points[10];
 for(i=0;i<10;i++)
   {
    points[i].x = rand() % 100 + 1;
    points[i].y = rand() % 100 + 1;
   }

 for(i=0;i<10;i++)             
 printf("\n%d %d\n", points[i].x, points[i].y);
 return(0);
 }

