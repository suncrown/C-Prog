#include<stdio.h>

/* With help of the random rand() function  
 * Boxes/Shaps are constructed 
*/ 

struct Point
{
   int x, y;
};

struct Box
{
   struct Point M;
   struct Point N;
   struct Point Q;
   struct Point S;
};
 
int main()
{
 int i;
 struct Box boxes[10];
 for(i=0;i<10;i++)
   {
    boxes[i].M.x = rand() % 100 + 1 ; 
    boxes[i].M.y = rand() % 100 + 1 ;
    boxes[i].N.x = rand() % 100 + 1 ; 
    boxes[i].N.y = rand() % 100 + 1 ;
    boxes[i].Q.x = rand() % 100 + 1 ; 
    boxes[i].Q.y = rand() % 100 + 1 ;
    boxes[i].S.x = rand() % 100 + 1 ; 
    boxes[i].S.y = rand() % 100 + 1 ;
   }

 for(i=0;i<10;i++)             
 printf("\n%d %d %d %d %d %d %d %d\n", boxes[i].M.x, boxes[i].M.y, boxes[i].N.x,boxes[i].N.y, boxes[i].Q.x, boxes[i].Q.y,boxes[i].S.x,boxes[i].S.y );
 return(0);
 }

